# NOVA BOOST — Android Studio starter project

A Kotlin + Jetpack Compose starter app with:
- Login and registration demo flow
- Dark premium interface and animated intro
- Installed launcher-app list and launch action
- Device-wide RAM overview
- Home, Games, and Settings navigation

## Open in Android Studio
1. Extract this ZIP.
2. Android Studio → Open → choose the `NovaBoost` folder.
3. Allow Gradle sync. Use JDK 17.
4. Install Android SDK Platform 35 if prompted.
5. Run on an Android device or emulator.

## Build APK
Android Studio: Build → Build Bundle(s) / APK(s) → Build APK(s).

Or from the project root:
`./gradlew assembleDebug`

APK output:
`app/build/outputs/apk/debug/app-debug.apk`

## Important limitations
- Authentication is a local demo only. It is not cloud sync and is not suitable for production accounts. Replace it with Firebase Authentication or another secure backend before publishing.
- The demo stores a SHA-256 password digest in local app preferences. This is not a production password-storage design.
- The game list shows launchable apps visible through Android package-visibility rules. It cannot reliably identify every game on every device.
- The Boost action launches the selected game. Android does not allow ordinary apps to forcibly clear other apps' RAM or guarantee FPS improvements. RAM figures are device-wide estimates from Android's ActivityManager.
- The RAM monitor refreshes while the Home screen is active.

## Package
`com.novaboost.app`
