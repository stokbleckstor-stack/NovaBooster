package com.novaboost.app

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.security.MessageDigest

private val Bg = Color(0xFF090D14)
private val Panel = Color(0xFF151D2A)
private val Blue = Color(0xFF3987FF)
private val Muted = Color(0xFF9AA8BC)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(9, 13, 20)
        window.navigationBarColor = android.graphics.Color.rgb(9, 13, 20)
        setContent { NovaApp() }
    }
}

private enum class Screen { LOGIN, REGISTER, HOME, GAMES, SETTINGS }
private data class Game(val label: String, val packageName: String)

@Composable
private fun NovaApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("nova_local_demo", Context.MODE_PRIVATE) }
    var screen by remember { mutableStateOf(Screen.LOGIN) }
    var signedIn by remember { mutableStateOf(prefs.getBoolean("signed_in", false)) }
    var username by remember { mutableStateOf(prefs.getString("username", "") ?: "") }

    LaunchedEffect(signedIn) { if (signedIn) screen = Screen.HOME }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Blue,
            background = Bg,
            surface = Panel,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            when (screen) {
                Screen.LOGIN -> AuthScreen(
                    register = false,
                    onSwitch = { screen = Screen.REGISTER },
                    onSuccess = {
                        username = it
                        prefs.edit().putBoolean("signed_in", true).putString("username", it).apply()
                        signedIn = true
                        screen = Screen.HOME
                    }
                )
                Screen.REGISTER -> AuthScreen(
                    register = true,
                    onSwitch = { screen = Screen.LOGIN },
                    onSuccess = {
                        username = it
                        prefs.edit().putBoolean("signed_in", true).putString("username", it).apply()
                        signedIn = true
                        screen = Screen.HOME
                    }
                )
                Screen.HOME -> MainShell(
                    username = username.ifBlank { "Gamer" },
                    initialTab = 0,
                    onLogout = {
                        prefs.edit().putBoolean("signed_in", false).apply()
                        signedIn = false
                        screen = Screen.LOGIN
                    }
                )
                Screen.GAMES -> MainShell(username, 1) {
                    prefs.edit().putBoolean("signed_in", false).apply()
                    signedIn = false
                    screen = Screen.LOGIN
                }
                Screen.SETTINGS -> MainShell(username, 2) {
                    prefs.edit().putBoolean("signed_in", false).apply()
                    signedIn = false
                    screen = Screen.LOGIN
                }
            }
        }
    }
}

@Composable
private fun AuthScreen(
    register: Boolean,
    onSwitch: () -> Unit,
    onSuccess: (String) -> Unit
) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("nova_local_demo", Context.MODE_PRIVATE) }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    var visible by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { delay(180); visible = true }

    Box(Modifier.fillMaxSize().background(
        Brush.verticalGradient(listOf(Color(0xFF101D32), Bg, Bg))
    )) {
        Column(
            Modifier.fillMaxSize().imePadding().padding(horizontal = 26.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            AnimatedVisibility(visible, enter = fadeIn() + slideInVertically { it / 3 }) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        Modifier.size(76.dp).clip(RoundedCornerShape(24.dp))
                            .background(Brush.linearGradient(listOf(Blue, Color(0xFF17417C)))),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("N", fontSize = 42.sp, fontWeight = FontWeight.Black, color = Color.White)
                    }
                    Spacer(Modifier.height(18.dp))
                    Text("NOVA BOOST", fontSize = 25.sp, letterSpacing = 3.sp,
                        fontWeight = FontWeight.ExtraBold, color = Color.White)
                    Text("YOUR GAMING SPACE", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
                    Spacer(Modifier.height(42.dp))
                    Text(if (register) "Create account" else "Welcome back",
                        Modifier.fillMaxWidth(), fontSize = 25.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text(if (register) "Create your local NOVA profile." else "Sign in to continue.",
                        Modifier.fillMaxWidth(), color = Muted, fontSize = 13.sp)
                    Spacer(Modifier.height(25.dp))
                    NovaTextField(email, { email = it }, "Email", false)
                    Spacer(Modifier.height(13.dp))
                    NovaTextField(password, { password = it }, "Password", true)
                    if (register) {
                        Spacer(Modifier.height(13.dp))
                        NovaTextField(confirm, { confirm = it }, "Confirm password", true)
                    }
                    Spacer(Modifier.height(20.dp))
                    Button(
                        onClick = {
                            error = when {
                                email.isBlank() || password.isBlank() -> "Email and password are required."
                                !email.contains("@") -> "Enter a valid email address."
                                password.length < 6 -> "Password must be at least 6 characters."
                                register && password != confirm -> "Passwords do not match."
                                register && prefs.contains("user_${email.lowercase()}") -> "Account already exists."
                                !register && prefs.getString("user_${email.lowercase()}", null) != sha256(password) -> "Email or password is incorrect."
                                else -> ""
                            }
                            if (error.isEmpty()) {
                                if (register) prefs.edit().putString("user_${email.lowercase()}", sha256(password)).apply()
                                onSuccess(email.substringBefore("@"))
                            }
                        },
                        Modifier.fillMaxWidth().height(54.dp),
                        shape = RoundedCornerShape(15.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Blue)
                    ) {
                        Text(if (register) "CREATE ACCOUNT" else "SIGN IN",
                            fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                    }
                    if (error.isNotEmpty()) {
                        Spacer(Modifier.height(12.dp))
                        Text(error, color = Color(0xFFFF8585), fontSize = 12.sp)
                    }
                    Spacer(Modifier.height(20.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(if (register) "Already have an account? " else "New to NOVA? ",
                            color = Muted, fontSize = 13.sp)
                        Text(if (register) "Sign in" else "Create account",
                            color = Color(0xFF70A9FF), fontWeight = FontWeight.Bold,
                            modifier = Modifier.clickable { onSwitch() }, fontSize = 13.sp)
                    }
                }
            }
        }
    }
}

private fun sha256(value: String): String =
    MessageDigest.getInstance("SHA-256").digest(value.toByteArray())
        .joinToString("") { "%02x".format(it) }

@Composable
private fun NovaTextField(
    value: String,
    onValueChange: (String) -> Unit,
    hint: String,
    password: Boolean
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = Modifier.fillMaxWidth(),
        placeholder = { Text(hint, color = Muted) },
        singleLine = true,
        visualTransformation = if (password) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
        keyboardOptions = if (password) KeyboardOptions(keyboardType = KeyboardType.Password)
            else KeyboardOptions(keyboardType = KeyboardType.Email),
        shape = RoundedCornerShape(14.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Blue,
            unfocusedBorderColor = Color(0xFF29384D),
            focusedContainerColor = Panel,
            unfocusedContainerColor = Panel,
            focusedTextColor = Color.White,
            unfocusedTextColor = Color.White
        )
    )
}

@Composable
private fun MainShell(username: String, initialTab: Int, onLogout: () -> Unit) {
    var tab by remember { mutableIntStateOf(initialTab) }
    Scaffold(
        containerColor = Bg,
        bottomBar = {
            NavigationBar(containerColor = Panel) {
                NavigationBarItem(selected = tab == 0, onClick = { tab = 0 },
                    icon = { Icon(Icons.Default.Dashboard, null) }, label = { Text("Home") })
                NavigationBarItem(selected = tab == 1, onClick = { tab = 1 },
                    icon = { Icon(Icons.Default.SportsEsports, null) }, label = { Text("Games") })
                NavigationBarItem(selected = tab == 2, onClick = { tab = 2 },
                    icon = { Icon(Icons.Default.Settings, null) }, label = { Text("Settings") })
            }
        }
    ) { padding ->
        when (tab) {
            0 -> HomeScreen(username, Modifier.padding(padding), onGames = { tab = 1 })
            1 -> GamesScreen(Modifier.padding(padding))
            else -> SettingsScreen(username, Modifier.padding(padding), onLogout)
        }
    }
}

@Composable
private fun HomeScreen(username: String, modifier: Modifier, onGames: () -> Unit) {
    val context = LocalContext.current
    var memory by remember { mutableStateOf(readMemory(context)) }
    LaunchedEffect(Unit) {
        while (true) { memory = readMemory(context); delay(2500) }
    }
    Column(modifier.fillMaxSize().padding(22.dp)) {
        Text("NOVA BOOST", color = Color.White, fontSize = 13.sp,
            fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        Spacer(Modifier.height(26.dp))
        Text("Good day,", color = Muted, fontSize = 14.sp)
        Text(username, color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(24.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Panel),
            shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(20.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Memory, null, tint = Blue)
                    Spacer(Modifier.width(9.dp))
                    Text("MEMORY OVERVIEW", color = Muted, fontSize = 11.sp, letterSpacing = 1.4.sp)
                }
                Spacer(Modifier.height(18.dp))
                Text("${memory.usedMb} MB", fontSize = 32.sp, color = Color.White,
                    fontWeight = FontWeight.Bold)
                Text("Estimated RAM in use • ${memory.totalMb} MB total",
                    color = Muted, fontSize = 12.sp)
                Spacer(Modifier.height(15.dp))
                LinearProgressIndicator(
                    progress = { memory.usedRatio },
                    modifier = Modifier.fillMaxWidth().height(7.dp).clip(CircleShape),
                    color = Blue,
                    trackColor = Color(0xFF2B3545)
                )
                Spacer(Modifier.height(8.dp))
                Text("${(memory.usedRatio * 100).toInt()}% used",
                    color = Muted, fontSize = 11.sp)
            }
        }
        Spacer(Modifier.height(18.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF142744)),
            shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()
                .clickable { onGames() }) {
            Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.RocketLaunch, null, tint = Color(0xFF83B7FF),
                    modifier = Modifier.size(34.dp))
                Spacer(Modifier.width(15.dp))
                Column(Modifier.weight(1f)) {
                    Text("Game launcher", fontWeight = FontWeight.Bold, color = Color.White)
                    Text("Choose a game and launch it", color = Muted, fontSize = 12.sp)
                }
                Icon(Icons.Default.ChevronRight, null, tint = Color.White)
            }
        }
        Spacer(Modifier.height(20.dp))
        Text("QUICK NOTE", color = Muted, fontSize = 10.sp, letterSpacing = 1.5.sp)
        Spacer(Modifier.height(8.dp))
        Text("NOVA can launch your installed games and show device memory information. Android controls memory management automatically.",
            color = Muted, fontSize = 13.sp, lineHeight = 19.sp)
    }
}

private data class MemoryStats(val usedMb: Long, val totalMb: Long, val usedRatio: Float)

private fun readMemory(context: Context): MemoryStats {
    val manager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    val info = ActivityManager.MemoryInfo()
    manager.getMemoryInfo(info)
    val total = info.totalMem.coerceAtLeast(1L)
    val used = (total - info.availMem).coerceIn(0L, total)
    return MemoryStats(used / 1024 / 1024, total / 1024 / 1024,
        (used.toFloat() / total).coerceIn(0f, 1f))
}

@Composable
private fun GamesScreen(modifier: Modifier) {
    val context = LocalContext.current
    var games by remember { mutableStateOf(emptyList<Game>()) }
    var loading by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        games = loadGames(context)
        loading = false
    }

    Column(modifier.fillMaxSize().padding(22.dp)) {
        Text("YOUR GAMES", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Text("Launch games installed on this device.", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(18.dp))
        when {
            loading -> Box(Modifier.fillMaxWidth().padding(30.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = Blue)
            }
            games.isEmpty() -> Text("No launchable games were found. Install a game and reopen this page.",
                color = Muted, fontSize = 13.sp)
            else -> LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(games, key = { it.packageName }) { game ->
                    Card(
                        modifier = Modifier.fillMaxWidth().clickable { launchGame(context, game.packageName) },
                        colors = CardDefaults.cardColors(containerColor = Panel),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.SportsEsports, null, tint = Blue, modifier = Modifier.size(30.dp))
                            Spacer(Modifier.width(13.dp))
                            Column(Modifier.weight(1f)) {
                                Text(game.label, color = Color.White, fontWeight = FontWeight.SemiBold)
                                Text("Tap to launch", color = Muted, fontSize = 11.sp)
                            }
                            Icon(Icons.Default.PlayArrow, null, tint = Blue)
                        }
                    }
                }
            }
        }
    }
}

@Suppress("DEPRECATION")
private fun loadGames(context: Context): List<Game> {
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return context.packageManager.queryIntentActivities(intent, PackageManager.MATCH_ALL)
        .mapNotNull { info ->
            val packageName = info.activityInfo?.packageName ?: return@mapNotNull null
            val label = info.loadLabel(context.packageManager)?.toString() ?: packageName
            if (packageName == context.packageName) null else Game(label, packageName)
        }
        .distinctBy { it.packageName }
        .sortedBy { it.label.lowercase() }
}

private fun launchGame(context: Context, packageName: String) {
    val launch = context.packageManager.getLaunchIntentForPackage(packageName) ?: return
    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    context.startActivity(launch)
}

@Composable
private fun SettingsScreen(username: String, modifier: Modifier, onLogout: () -> Unit) {
    Column(modifier.fillMaxSize().padding(22.dp)) {
        Text("SETTINGS", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(20.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Panel),
            shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp)) {
                Text("Signed in as", color = Muted, fontSize = 12.sp)
                Text(username, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("NOVA BOOST • Version 1.0", color = Muted, fontSize = 11.sp)
            }
        }
        Spacer(Modifier.height(20.dp))
        OutlinedButton(onClick = onLogout, modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp)) {
            Icon(Icons.Default.Logout, null)
            Spacer(Modifier.width(8.dp))
            Text("Sign out")
        }
        Spacer(Modifier.height(18.dp))
        Text("This starter app stores demo accounts locally on this device. Use a secure backend before publishing or handling real accounts.",
            color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
    }
}
